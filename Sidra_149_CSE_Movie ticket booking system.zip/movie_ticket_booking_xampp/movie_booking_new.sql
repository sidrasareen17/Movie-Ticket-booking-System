-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 05, 2025 at 08:03 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `movie_booking_new`
--

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

CREATE TABLE `bookings` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `movie_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `booking_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bookings`
--

INSERT INTO `bookings` (`id`, `user_id`, `movie_id`, `date`, `booking_time`) VALUES
(1, 3, 18, '2025-12-12', '2025-12-03 19:56:39'),
(2, 3, 17, '2025-12-24', '2025-12-03 19:56:53'),
(3, 3, 17, '2025-12-24', '2025-12-03 19:59:00'),
(4, 3, 18, '2025-12-12', '2025-12-03 19:59:26'),
(5, 3, 16, '2025-12-19', '2025-12-03 20:02:46'),
(6, 3, 17, '2025-12-05', '2025-12-03 20:05:51'),
(7, 7, 18, '2025-12-13', '2025-12-03 20:13:57'),
(8, 10, 17, '2025-12-20', '2025-12-04 05:11:29'),
(9, 12, 16, '2025-12-13', '2025-12-04 14:52:06'),
(10, 1, 13, '2025-12-18', '2025-12-05 06:21:40'),
(11, 16, 17, '2025-12-21', '2025-12-05 06:43:05'),
(12, 16, 12, '2025-12-20', '2025-12-05 07:49:10'),
(13, 16, 13, '2025-12-13', '2025-12-05 10:03:58');

-- --------------------------------------------------------

--
-- Table structure for table `movies`
--

CREATE TABLE `movies` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `year` int(11) DEFAULT NULL,
  `duration` int(11) DEFAULT NULL,
  `description` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `movies`
--

INSERT INTO `movies` (`id`, `name`, `price`, `year`, `duration`, `description`) VALUES
(1, 'Avengers Endgame', 300, 2019, 180, 'Superhero action movie'),
(2, 'KGF Chapter 2', 250, 2022, 168, 'Action drama movie'),
(3, 'Leo', 200, 2023, 160, 'Action thriller movie'),
(4, 'Avatar: The Way of Water', 350, 2022, 192, 'Epic sci-fi adventure'),
(5, 'Spider-Man: No Way Home', 280, 2021, 148, 'Marvel multiverse action movie'),
(6, 'Inception', 220, 2010, 148, 'Mind-bending sci-fi thriller'),
(7, 'The Dark Knight', 260, 2008, 152, 'Batman battles Joker'),
(8, 'Interstellar', 300, 2014, 169, 'Space exploration sci-fi drama'),
(9, 'Jawan', 270, 2023, 169, 'Action thriller starring Shah Rukh Khan'),
(10, 'Pathaan', 240, 2023, 146, 'Spy action movie starring SRK'),
(11, 'RRR', 280, 2022, 187, 'Epic action drama by Rajamouli'),
(12, 'Pushpa: The Rise', 200, 2021, 179, 'Action drama starring Allu Arjun'),
(13, 'Bahubali: The Beginning', 230, 2015, 158, 'Epic historical action movie'),
(14, 'Bahubali 2: The Conclusion', 260, 2017, 171, 'Epic battle action film'),
(15, 'Dangal', 180, 2016, 161, 'Sports biographical drama'),
(16, '3 Idiots', 150, 2009, 170, 'Comedy drama about engineering students'),
(17, 'Tenet', 250, 2020, 150, 'Time-inversion sci-fi action'),
(18, 'The Matrix', 200, 1999, 136, 'Sci-fi about simulated reality');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` int(11) NOT NULL,
  `booking_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `payment_method` varchar(50) DEFAULT 'card',
  `payment_status` enum('pending','paid','failed') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`id`, `booking_id`, `user_id`, `amount`, `payment_method`, `payment_status`, `created_at`) VALUES
(1, 3, 3, 250.00, 'card', 'paid', '2025-12-03 18:59:00'),
(2, 4, 3, 200.00, 'card', 'paid', '2025-12-03 18:59:26'),
(3, 5, 3, 600.00, 'card', 'paid', '2025-12-03 19:02:46'),
(4, 6, 3, 250.00, 'upi', 'paid', '2025-12-03 19:05:51'),
(5, 7, 7, 200.00, 'upi', 'paid', '2025-12-03 19:13:57'),
(6, 8, 10, 250.00, 'upi', 'paid', '2025-12-04 04:11:30'),
(7, 9, 12, 150.00, 'card', 'paid', '2025-12-04 13:52:06'),
(8, 10, 1, 690.00, 'card', 'paid', '2025-12-05 05:21:40'),
(9, 11, 16, 250.00, 'upi', 'paid', '2025-12-05 05:43:05'),
(10, 12, 16, 200.00, 'card', 'paid', '2025-12-05 06:49:10'),
(11, 13, 16, 690.00, 'card', 'paid', '2025-12-05 09:03:58');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`) VALUES
(1, 'shaikh sid', 'shaikh@1234', '$2y$10$7F6yIOaBqsQpnJnmtEj91eO3EoTHHAI6KEwTLuGhX1uuVJz0mUj/C'),
(2, 'shaikh sid', 'sidra@gmail.com', '$2y$10$XawGs1hDRAxcOOqsU5z8tOWoHoXERFeH43w7b53PMmgM1.2Eds/ZG'),
(3, 'sidra', 'sid@1234', '$2y$10$8xx6p3PLFu4yswKqhbihZurohosmCsK7WcsdBoafpG5ERTEFb3o1a'),
(4, 'shaikh sid', 'sid@1234', '$2y$10$l6NjpzUKyZCW4gCKzK13HOnpF1MK7dgaFuY2KBV7uRyRvkEe753h.'),
(5, 'shaikh sid', 'sid@1234', '$2y$10$e4l.Q/TgEiXCDYlZSHkrG.kQnqXfn7UCmrP07nmpl6VstmStSynti'),
(6, NULL, NULL, '$2y$10$Y13ykmetDQfy/tS1A8G3aOvpkuMcTvVAKErk8l13zu4qox/sPifF2'),
(7, 'sidra', 'sid@1234', '$2y$10$09e/NK94rBeuTl5NdzDCV.WBoVZU1cqtjQ9A1pv28gqvzLuJeHdrq'),
(8, 'seema', 'seema@gmail.com', '$2y$10$uB009UieGDe6CW4.Yp6BSu5T2/RdiOCz0y8OtgdDTs2JONqKgIVA2'),
(9, 'seema', 'seema@gmail.com', '$2y$10$c7Vkb/O5V5ng665b986mrucHMOnKR6xXh.l6/Mj8LZP4H/zKqv9WW'),
(10, 'sidra', 'shaikh@1234', '$2y$10$hX3gCuJkZJgDDg0EcmjJGe4RMDSi9ep1AoQMm4.wJzJJ1zg8SqV6q'),
(11, 'shaikh sid', 'shaikh@1234', '$2y$10$FLCbV9S858qpzZfhOKMJFuX0P25Tb1y/Z9N.fSZi5Ic8vQnSOGfbK'),
(12, 'shaikh sid', 'riya@gmail.com', '$2y$10$oHnjAmWM8Q9i6P8Nk8Q80.4ol1IpmAckpzX0DVWh9/fjFZlbHcbwK'),
(13, 'sidra', 'shaikh@1234', '$2y$10$U6YPRjS5cr0ODxBx4rYA0uHXGbGjWvIJYPF/XxHXl7216MjAsPB5W'),
(14, 'sidra', 'shaikh@1234', '$2y$10$dya4/RBNAVk3He8YaMH.N.jVKuesXO1PjNlzgs92I9.xDl7KRjjVG'),
(15, 'sidra', 'shaikh@1234', '$2y$10$IZEtgzYvov0yQhlXaAzI2e54C4chhEDDHEW8kaSjskzmBZJYrugoC'),
(16, 'sidra sareen', 'sareen@gmail.com', '$2y$10$dCn0WoH72TyuQb7fw/7KGe3k5X2AF2SlTrW/Ew/8aKCc9q1Nk/vGK'),
(17, 'sidra sareen', 'sareen@gmail.com', '$2y$10$15M5xnGJK4isBp8F34NIX.LoDLwD.9PkjXdUb3K6LUUhM15.HV8Ce'),
(18, 'sidra sareen', 'sareen@gmail.com', '$2y$10$utqo9LkJLtRzb7b8mjRLu.puhE03NQecGixci5uchy3RbSOqNK73y'),
(19, 'sidra sareen', 'sareen@gmail.com', '$2y$10$yLQSE74xl8fwTVNRacCPK.HktosEJRHnu8Y/fzWU9Ll5bBIQGfFie');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bookings`
--
ALTER TABLE `bookings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_booking_user` (`user_id`),
  ADD KEY `fk_booking_movie` (`movie_id`);

--
-- Indexes for table `movies`
--
ALTER TABLE `movies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_payment_booking` (`booking_id`),
  ADD KEY `fk_payment_user` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bookings`
--
ALTER TABLE `bookings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `movies`
--
ALTER TABLE `movies`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `bookings`
--
ALTER TABLE `bookings`
  ADD CONSTRAINT `fk_booking_movie` FOREIGN KEY (`movie_id`) REFERENCES `movies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_booking_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `payments`
--
ALTER TABLE `payments`
  ADD CONSTRAINT `fk_payment_booking` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_payment_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
