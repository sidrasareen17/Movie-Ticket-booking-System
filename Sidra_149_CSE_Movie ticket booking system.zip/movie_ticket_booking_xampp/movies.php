<?php
session_start();
require_once 'config.php';

$res = $mysqli->query("SELECT * FROM movies ORDER BY id DESC");
$movies = $res ? $res->fetch_all(MYSQLI_ASSOC) : [];
?>
<!DOCTYPE html>
<html>
<head>
<title>Movies</title>

<style>
/* ===== GENERAL PAGE STYLE ===== */
body {
    font-family: 'Poppins', sans-serif;
    background: #f4f4f9;
    margin: 0;
    padding: 0;
    color: #333;
}

.container {
    width: 95%;
    max-width: 1200px;
    margin: 30px auto;
}

/* ===== HEADER ===== */
.header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 25px;
}

.header h1 {
    color: #2c3e50;
    font-size: 32px;
    letter-spacing: 1px;
}

.header nav a {
    text-decoration: none;
    color: #2980b9;
    margin-left: 15px;
    font-weight: 600;
}

.header nav a:hover {
    color: #1a5276;
    text-decoration: underline;
}

/* ===== MOVIE GRID ===== */
.movie-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
    gap: 22px;
}

/* ===== MOVIE CARD (WITHOUT POSTER) ===== */
.movie {
    background: #ffffff;
    border-radius: 14px;
    padding: 20px;
    text-align: left;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
    transition: transform .25s ease, box-shadow .25s ease;
}

.movie:hover {
    transform: translateY(-6px);
    box-shadow: 0 10px 20px rgba(0, 0, 0, 0.15);
}

.movie h3 {
    margin: 0 0 8px 0;
    color: #2c3e50;
    font-size: 22px;
    font-weight: 700;
}

.movie p {
    font-size: 14px;
    margin: 6px 0;
    color: #555;
}

/* ===== BOOK NOW BUTTON ===== */
.btn {
    display: inline-block;
    background: #27ae60;
    color: #fff;
    padding: 10px 18px;
    border-radius: 8px;
    margin-top: 12px;
    font-size: 15px;
    font-weight: 600;
    text-decoration: none;
    transition: background .3s ease, transform .2s ease;
}

.btn:hover {
    background: #1e8449;
    transform: scale(1.05);
}
</style>

</head>
<body>

<div class="container">

    <div class="header">
        <h1>🎬 Movies</h1>

        <nav>
            <a href="index.php">Home</a>

            <?php if(isset($_SESSION['user'])): ?>
                Hello, <?=htmlspecialchars($_SESSION['user']['name'])?> |
                <a href="logout.php">Logout</a>
            <?php else: ?>
                <a href="login.php">Login</a> |
                <a href="register.php">Register</a>
            <?php endif; ?>
        </nav>
    </div>

    <div class="movie-grid">

        <?php foreach($movies as $m): ?>
        <div class="movie">
            <h3><?=htmlspecialchars($m['name'])?></h3>

            <p><strong>Year:</strong> <?=$m['year']?></p>
            <p><strong>Duration:</strong> <?=$m['duration']?> min</p>
            <p><strong>Price:</strong> ₹<?=$m['price']?></p>

            <a class="btn" href="book.php?movie_id=<?=$m['id']?>">Book Now</a>
        </div>
        <?php endforeach; ?>

    </div>

</div>

</body>
</html>
