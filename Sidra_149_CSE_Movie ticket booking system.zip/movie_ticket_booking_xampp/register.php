<?php
session_start();
require_once 'config.php';

if($_SERVER['REQUEST_METHOD'] == "POST"){
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    // Insert user into database
    $stmt = $mysqli->prepare("INSERT INTO users (name, email, password) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $name, $email, $password);

    if($stmt->execute()){
        // Redirect to login after successful registration
        header("Location: login.php?registered=1");
        exit;
    } else {
        $error = "Email already exists!";
    }

    $stmt->close();
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Register</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">

<h2>Register</h2>

<?php 
// Success message when redirected back from registration
if(isset($_GET['registered'])){
    echo "<p class='success'>Registration successful! Please login.</p>";
}
?>

<?php 
if(isset($error)){ 
    echo "<p class='error'>$error</p>"; 
} 
?>

<form method="post">
<label>Name</label>
<input type="text" name="name" required>

<label>Email</label>
<input type="email" name="email" required>

<label>Password</label>
<input type="password" name="password" required>

<button type="submit">Register</button>

<p>Already have an account? <a href="login.php">Login</a></p>
</form>

</div>
</body>
</html>
