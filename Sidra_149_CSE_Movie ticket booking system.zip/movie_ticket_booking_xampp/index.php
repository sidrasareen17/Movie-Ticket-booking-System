<?php
session_start();
require_once 'config.php';
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Movie Booking - Home</title>
  <link rel="stylesheet" href="assets/style.css">
</head>
<body>
<div class="container">
  <div class="header">
    <h1>Movie Ticket Booking</h1>
    <nav>
      <?php if(isset($_SESSION['user'])): ?>
        Hello, <?=htmlspecialchars($_SESSION['user']['username'])?> |
        <a href="movies.php">Movies</a>
        <a href="logout.php">Logout</a>
      <?php else: ?>
        <a href="register.php">Register</a>
        <a href="login.php">Login</a>
      <?php endif; ?>
    </nav>
  </div>

  <p>Welcome to the Movie Booking System. Browse movies and book your tickets.</p>

  <a class="btn" href="movies.php">Browse Movies</a>

  <div class="footer">Built for XAMPP demo</div>
</div>
</body>
</html>
