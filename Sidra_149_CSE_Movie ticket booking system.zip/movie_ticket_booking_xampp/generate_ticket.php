<?php
session_start();
if(!isset($_SESSION['ticket'])){ header("Location: movies.php"); exit; }
$t=$_SESSION['ticket'];
?>
<!DOCTYPE html>
<html>
<head>
<title>Ticket</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
<div class="ticket">
<h2>🎬 Movie Ticket 🎬</h2>
<p>User: <?=$t['user']['name']?></p>
<p>Movie: <?=$t['movie']['name']?></p>
<p>Date: <?=$t['date']?></p>
<p>Seats: <?=$t['seats']?></p>
<p>Total: ₹<?=$t['movie']['price']?></p>
<button onclick="downloadTicket()">Download Ticket</button>
</div>
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
<script>
function downloadTicket(){
    html2canvas(document.querySelector('.ticket')).then(canvas=>{
        const link=document.createElement('a');
        link.download='ticket_<?=$t['movie']['name']?>.png';
        link.href=canvas.toDataURL();
        link.click();
    });
}
</script>
</body>
</html>
