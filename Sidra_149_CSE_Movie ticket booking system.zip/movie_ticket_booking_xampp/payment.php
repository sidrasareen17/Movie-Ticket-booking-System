<?php
session_start();

//////////////////////////////////////
// CONFIG.PHP CONTENT INCLUDED HERE //
//////////////////////////////////////

$host = "localhost";
$user = "root";
$pass = "";
$db   = "movie_booking_new";

$mysqli = new mysqli($host, $user, $pass, $db);

if ($mysqli->connect_error) {
    die("Database Error: " . $mysqli->connect_error);
}

date_default_timezone_set("Asia/Kolkata");

//////////////////////////////////////
// END CONFIG
//////////////////////////////////////

// PAGE SECURITY
if($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_SESSION['user'])){
    header("Location: movies.php"); 
    exit;
}

// FETCH POST DATA
$movie_id = intval($_POST['movie_id']);
$show_date = $mysqli->real_escape_string($_POST['date']);
$seats = intval($_POST['seats']);
$user_id = $_SESSION['user']['id'];

// FETCH MOVIE INFORMATION
$stmt = $mysqli->prepare("SELECT * FROM movies WHERE id=?");
$stmt->bind_param("i", $movie_id);
$stmt->execute();
$movie = $stmt->get_result()->fetch_assoc();
$stmt->close();

$total = $movie['price'] * $seats;

// STORE BOOKING SESSION
$_SESSION['booking'] = [
    'movie_id'=>$movie_id,
    'movie_name'=>$movie['name'],
    'date'=>$show_date,
    'seats'=>$seats,
    'total'=>$total
];
?>
<!DOCTYPE html>
<html>
<head>
<title>Payment</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">

<h2>Payment for <?=htmlspecialchars($movie['name'])?></h2>
<p>Total Amount: ₹<?=$total?></p>

<form method="post" action="process_payment.php">

<label>Phone Number</label>
<input type="text" name="phone" placeholder="Enter phone number" required>

<label>UPI ID</label>
<input type="text" name="upi_id" placeholder="example@upi" required>

<label>Transaction PIN</label>
<input type="password" name="payment_pin" placeholder="Enter your UPI/Card PIN" required>

<label>Payment Method</label>
<select name="payment_method" required>
    <option value="upi">UPI</option>
    <option value="card">Card</option>
    <option value="netbanking">Net Banking</option>
</select>

<button type="submit">Pay & Generate Ticket</button>
</form>

</div>
</body>
</html>
