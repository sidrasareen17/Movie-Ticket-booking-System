<?php
// Minimal FPDF wrapper (compressed) for demo use
class FPDF
{
    protected $buffer='';
    protected $pages = array();
    protected $current_font='Arial';
    protected $FontSizePt=12;
    public function __construct(){ }
    public function AddPage(){ $this->pages[] = ''; }
    public function SetFont($family, $style='', $size=12){ $this->current_font=$family; $this->FontSizePt=$size; }
    public function Cell($w,$h,$txt,$border=0,$ln=0,$align=''){ $this->pages[count($this->pages)-1] .= $txt . "\n"; if($ln) $this->pages[count($this->pages)-1] .= "\n"; }
    public function Ln($h=0){ $this->pages[count($this->pages)-1] .= "\n"; }
    public function Output($dest='I',$name='doc.pdf'){
        // Build a very simple PDF by converting the pages text into a plain PDF.
        // NOTE: This is a very basic output and not a full PDF generator.
        header('Content-Type: application/pdf');
        header('Content-Disposition: attachment; filename="'.basename($name).'"');
        // For demo, output plain text as PDF-like content.
        echo "----- Ticket (simple text) -----\n\n";
        foreach($this->pages as $p) echo $p . "\n\n";
    }
}
?>