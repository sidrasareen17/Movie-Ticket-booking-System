
<?php
$host = "localhost";
$db   = "movie_booking_new"; // make sure this is your DB name
$user = "root";              // or your MySQL username
$pass = "";                  // or your MySQL password

$mysqli = new mysqli($host, $user, $pass, $db);

if ($mysqli->connect_errno) {
    die("Failed to connect to MySQL: " . $mysqli->connect_error);
}
?>
