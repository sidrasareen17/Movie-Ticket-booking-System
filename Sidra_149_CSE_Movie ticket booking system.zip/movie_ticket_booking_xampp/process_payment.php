<?php
session_start();
require_once 'config.php';
if(!isset($_SESSION['user']) || !isset($_SESSION['booking'])){
    header("Location: movies.php"); exit;
}

$user_id = $_SESSION['user']['id'];
$movie_id = $_SESSION['booking']['movie_id'];
$show_date = $_SESSION['booking']['date'];
$seats = $_SESSION['booking']['seats'];
$total = $_SESSION['booking']['total'];
$payment_method = $_POST['payment_method'] ?? 'card';

// Insert booking
$booking_time = date('Y-m-d H:i:s');
$stmt = $mysqli->prepare("INSERT INTO bookings (user_id, movie_id, date, booking_time) VALUES (?,?,?,?)");
$stmt->bind_param("iiss",$user_id,$movie_id,$show_date,$booking_time);
$stmt->execute();
$booking_id = $stmt->insert_id;
$stmt->close();

// Insert payment
$payment_status='paid';
$stmt = $mysqli->prepare("INSERT INTO payments (booking_id,user_id,amount,payment_method,payment_status) VALUES (?,?,?,?,?)");
$stmt->bind_param("iidss",$booking_id,$user_id,$total,$payment_method,$payment_status);
$stmt->execute();
$stmt->close();

// Store ticket info
$_SESSION['ticket'] = [
    'booking_id'=>$booking_id,
    'date'=>$show_date,
    'seats'=>$seats,
    'movie'=>[
        'name'=>$_SESSION['booking']['movie_name'],
        'price'=>$total
    ],
    'user'=>[
        'name'=>$_SESSION['user']['name'],
        'email'=>$_SESSION['user']['email']
    ]
];
unset($_SESSION['booking']);
header("Location: generate_ticket.php");
exit;
