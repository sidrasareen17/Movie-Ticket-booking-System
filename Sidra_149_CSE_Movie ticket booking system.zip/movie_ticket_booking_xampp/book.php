<?php
session_start();
require_once 'config.php';
if(!isset($_SESSION['user'])) header("Location: login.php");

$movie_id = intval($_GET['movie_id'] ?? 0);
if(!$movie_id) die("Movie not found");

$stmt = $mysqli->prepare("SELECT * FROM movies WHERE id=?");
$stmt->bind_param("i",$movie_id);
$stmt->execute();
$movie = $stmt->get_result()->fetch_assoc();
$stmt->close();
?>
<!DOCTYPE html>
<html>
<head>
<title>Book Movie</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
<h2>Book: <?=htmlspecialchars($movie['name'])?></h2>
<form method="post" action="payment.php">
<input type="hidden" name="movie_id" value="<?=$movie_id?>">
<label>Show Date</label><input type="date" name="date" required min="<?=date('Y-m-d')?>">
<label>Seats</label><input type="number" name="seats" min="1" value="1" required>
<button type="submit">Proceed to Payment</button>
</form>
</div>
</body>
</html>
