// assets/app.js
function confirmBooking() {
  return confirm('Proceed to book and pay (mock payment)?');
}
