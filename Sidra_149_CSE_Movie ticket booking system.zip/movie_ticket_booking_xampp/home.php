<?php
session_start();
if(!isset($_SESSION['user'])){ header("Location: login.php"); }

include "config.php";

$movies = $conn->query("SELECT * FROM movies");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Home - Movie Tickets</title>
<link rel="stylesheet" href="style.css">
<style>
/* Body and global styles */
body {
    font-family: 'Arial', sans-serif;
    background: #1c1c1c;
    color: #fff;
    margin: 0;
    padding: 0;
}

/* Welcome message */
h2 {
    text-align: center;
    margin: 30px 0;
    font-size: 28px;
    color: #ffd700;
}

/* Movie list container */
.movie-list {
    display: flex;
    flex-wrap: wrap;
    gap: 20px;
    justify-content: center;
    padding: 20px;
}

/* Movie card styling */
.movie-card {
    background: #2c2c2c;
    border-radius: 12px;
    width: 250px;
    padding: 20px;
    box-shadow: 0 8px 20px rgba(0,0,0,0.5);
    display: flex;
    flex-direction: column;
    justify-content: space-between;
}

.movie-card h3 {
    margin-top: 0;
    margin-bottom: 10px;
    font-size: 22px;
    color: #ffd700;
}

.movie-card p {
    margin: 5px 0;
    font-size: 14px;
    color: #ddd;
}

.price {
    font-size: 18px;
    color: #00ff00;
    font-weight: bold;
    margin-top: 10px;
}

/* Book Now button */
.btn {
    display: flex;
    align-items: center;
    justify-content: center;
    background: #ff4500;
    color: white;
    text-decoration: none;
    font-weight: bold;
    border-radius: 6px;
    padding: 10px;
    margin-top: 10px;
}
</style>
</head>
<body>

<h2>Welcome, <?php echo $_SESSION['user']['name']; ?></h2>

<div class="movie-list">
<?php while($m = $movies->fetch_assoc()): ?>
<div class="movie-card">
    <h3><?php echo $m['name']; ?></h3>
    <p>Year: <?php echo $m['year']; ?></p>
    <p>Duration: <?php echo $m['duration']; ?> mins</p>
    <p><?php echo $m['description']; ?></p>
    <p class="price">₹<?php echo $m['price']; ?></p>
    <a class="btn" href="book.php?id=<?php echo $m['id']; ?>">Book Now</a>
</div>
<?php endwhile; ?>
</div>

</body>
</html>
